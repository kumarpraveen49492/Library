-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 23, 2024 at 05:19 AM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `department library`
--

-- --------------------------------------------------------

--
-- Table structure for table `belongs`
--

DROP TABLE IF EXISTS `belongs`;
CREATE TABLE IF NOT EXISTS `belongs` (
  `ISBN` int NOT NULL,
  `CID` int NOT NULL,
  PRIMARY KEY (`ISBN`,`CID`),
  KEY `CID` (`CID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `ISBN` int NOT NULL,
  `TITTLE` text NOT NULL,
  `AUTHOR` text NOT NULL,
  `PRICE` int NOT NULL,
  `NO_OF_COPIES` int NOT NULL,
  `PID` int DEFAULT NULL,
  PRIMARY KEY (`ISBN`),
  KEY `PID` (`PID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`ISBN`, `TITTLE`, `AUTHOR`, `PRICE`, `NO_OF_COPIES`, `PID`) VALUES
(567, 'AWS DISCOVERY DAY', 'praveen', 567, 7, 45),
(1231, 'fdsdsgg', 'fghdjjdf', 32, 32, 5353);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `CID` int NOT NULL,
  `CNAME` text NOT NULL,
  `SEM` int NOT NULL,
  PRIMARY KEY (`CID`),
  UNIQUE KEY `SEM` (`SEM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lending`
--

DROP TABLE IF EXISTS `lending`;
CREATE TABLE IF NOT EXISTS `lending` (
  `DATE_DUE` date NOT NULL,
  `DATE_OUT` date NOT NULL,
  `ISBN` int NOT NULL,
  `USN` varchar(15) NOT NULL,
  PRIMARY KEY (`ISBN`,`USN`),
  KEY `USN` (`USN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

DROP TABLE IF EXISTS `publisher`;
CREATE TABLE IF NOT EXISTS `publisher` (
  `PID` int NOT NULL,
  `PNAME` text NOT NULL,
  PRIMARY KEY (`PID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`PID`, `PNAME`) VALUES
(1, 'fgdbdfh'),
(45, 'bhat'),
(345, 'fdtr'),
(5353, 'fgdbdfh');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `USN` varchar(15) NOT NULL,
  `NAME` text NOT NULL,
  `EMAIL` varchar(40) NOT NULL,
  `SEM` int NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  PRIMARY KEY (`USN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`USN`, `NAME`, `EMAIL`, `SEM`, `PASSWORD`) VALUES
('4JN21AI028', 'PRAVEEN', 'praveen@gmail.com', 5, '827ccb0eea8a706c4c34a16891f84e7b');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
