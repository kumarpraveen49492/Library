from flask import Flask, flash, render_template, request, redirect, url_for, session
from flask_cors import CORS
from flask_mysqldb import MySQL
from pytz import timezone
from datetime import datetime, timedelta
from dateutil import parser 
import pytz
import json
from json import JSONEncoder
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'your secret key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'department library'

mysql = MySQL(app)

users = {
    'root': generate_password_hash('root')
}

@app.route('/navigate/<int:m>')
def navigate_library(m):
    if m == 1:
        return render_template('index.html')
    elif m == 2:
        return render_template('deptlogin.html')
    elif m == 3:
        return render_template('about.html')
    elif m == 4:
        return render_template('lending.html')
    elif m == 5:
        return render_template('return.html')
    elif m == 6:
        return render_template('book_management.html')
    elif m == 7:
        return render_template('student_mangement.html')
    elif m == 8:
        return render_template('logs.html')
    elif m == 9:
        return render_template('student_login.html')
    elif m==10:
        return render_template('publisher.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    if username in users and check_password_hash(users[username], password):
        session['username'] = username
        return render_template('/main.html')
    else:
        return 'Invalid username or password', 401

@app.route('/logout')
def logout():
    session.pop('username', None)
    return render_template('/index.html')

@app.route('/student_signup', methods=['POST'])
def student_signup():
    uname = request.form.get('uname')
    usn = request.form.get('usn')
    email = request.form.get('email')
    sem = request.form.get('sem')
    pwd = request.form.get('pwd')
    
    cursor = mysql.connection.cursor()
    cursor.execute(''' INSERT INTO student(NAME,USN,EMAIL,SEM,PASSWORD) VALUES(%s,%s,%s,%s,MD5(%s))''',(uname,usn,email,sem,pwd))
    mysql.connection.commit()
    cursor.close()
    
    # Redirect to the login page after successful signup
    return render_template('/student_login.html')


@app.route('/stulogin', methods=['GET', 'POST'])
def stulogin():
    if request.method == 'POST':
        usn = request.form['usn']
        pwd = request.form['pwd']
        
        cur = mysql.connection.cursor()
        print(usn,pwd)
        cur.execute("SELECT PASSWORD FROM student WHERE USN=%s and PASSWORD=MD5(%s)", (usn,pwd))
        result = cur.fetchone()
        
        if result:
            return render_template('/student.html')
        else:
            return "Invalid credentials!"
    return render_template('/student_login.html')

@app.route('/student')
def student():
    return render_template('/student.html')

@app.route('/lend_book', methods=['POST'])
def lend_book():
    isbn = request.form.get('isbn')
    usn = request.form.get('usn')
    lending_date = datetime.now().date()
    due_date = lending_date + timedelta(days=10)

    cur = mysql.connection.cursor()
    
    try:
        cur.execute("INSERT INTO lending(DATE_OUT, ISBN, USN) VALUES(%s, %s,%s)", (lending_date, isbn, usn))
        mysql.connection.commit()
        cur.execute("UPDATE book SET NO_OF_COPIES = NO_OF_COPIES - 1 WHERE ISBN = %s", (isbn,))
        mysql.connection.commit()
        
        cur.close()
    except:
        return "Already you have taken the book"

    return "Lendin success"

@app.route('/add_student', methods=['POST'])
def add_student():
    usn = request.form.get('usn')
    name = request.form.get('sname')
    email = request.form.get('mail')
    sem = request.form.get('sem')
    pwd = request.form.get('pwd')

    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO student(USN, NAME, EMAIL, SEM,PASSWORD) VALUES(%s, %s, %s, %s,MD5(%s))", (usn, name, email, sem,pwd))
    mysql.connection.commit()
    cur.close()

    flash('Student has been added successfully!', 'success')
    return render_template('/student_mangement.html')

@app.route('/add_book', methods=['GET', 'POST'])
def add_book():
    if request.method == 'POST':
        isbn = request.form.get('isbn')
        title = request.form.get('bname')
        author = request.form.get('aname')
        price = request.form.get('price') 
        no_of_copies = request.form.get('nob')
        pub_id = request.form.get('pid')

        cur = mysql.connection.cursor()
        try:
            cur.execute("INSERT INTO book(ISBN, TITTLE, AUTHOR, PRICE, NO_OF_COPIES, PID) VALUES(%s, %s, %s, %s, %s, %s)", (isbn, title, author, price, no_of_copies, pub_id))
            mysql.connection.commit()
        except Exception as e:
            print("An error occurred: ", e)
            mysql.connection.rollback()
        finally:
            cur.close()

        flash('Book has been added successfully!', 'success')
        return render_template('/book_management.html')
    elif request.method == 'GET':
        
        return render_template('book_management.html')

@app.route('/add_pub',methods=['POST'])
def add_pub():

    pub_id = request.form.get('pid')
    pub_name = request.form.get('pname')

    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO publisher(PID, PNAME) VALUES(%s, %s)", (pub_id, pub_name))
    mysql.connection.commit()
    cur.close()
    return render_template('/publisher.html')


@app.route('/getpublishers', methods =['GET', 'POST'])

def getpublishers():
    
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM publisher")
    DBData = cursor.fetchall() 
    cursor.close()
    
    rtnames=''
    for result in DBData:
        print(result)
        rtnames+="<option value="+str(result[0])+">"+result[1]+"</option>"
    return rtnames 

@app.route('/getlendingusns', methods =['GET', 'POST'])

def getlendingusns():
    
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT S.USN,S.NAME FROM lending L,student S where L.USN=S.USN and L.DATE_DUE='0000-00-00'")
    DBData = cursor.fetchall() 
    cursor.close()
    
    rtnames=''
    for result in DBData:
        print(result)
        rtnames+="<option value="+str(result[0])+">"+result[1]+"</option>"
    return rtnames 

@app.route('/getallusns', methods =['GET', 'POST'])

def getallusns():
    
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT S.USN,S.NAME FROM student S ")
    DBData = cursor.fetchall() 
    cursor.close()
    
    rtnames=''
    for result in DBData:
        print(result)
        rtnames+="<option value="+str(result[0])+">"+result[1]+"</option>"
    return rtnames 

@app.route('/getlendingbooks', methods =['GET', 'POST'])

def getlendingbooks():
    
    cursor = mysql.connection.cursor()
    usn=request.form.get('usn')
    cursor.execute("SELECT L.ISBN,B.TITTLE FROM lending L,book B,student S where B.ISBN=L.ISBN and L.USN=S.USN and L.USN=%s",(usn,))
    DBData = cursor.fetchall() 
    cursor.close()
    
    rtnames=''
    for result in DBData:
        print(result)
        rtnames+="<option value="+str(result[0])+">"+result[1]+"</option>"
    return rtnames

@app.route('/getallbooks', methods =['GET', 'POST'])

def getallbooks():
    
    cursor = mysql.connection.cursor()
    usn=request.form.get('usn')
    cursor.execute("SELECT B.ISBN,B.TITTLE FROM book B where NO_OF_COPIES>0")
    DBData = cursor.fetchall() 
    cursor.close()
    
    rtnames=''
    for result in DBData:
        print(result)
        rtnames+="<option value="+str(result[0])+">"+result[1]+"</option>"
    return rtnames 

@app.route('/bookshow', methods =['GET', 'POST'])
def deptshow():
    
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM book")
    row_headers=[x[0] for x in cursor.description] 
    DBData = cursor.fetchall() 
    cursor.close()
    json_data=[]
    rstr="<table border><tr>"
    for r in row_headers:
        rstr=rstr+"<th>"+r+"</th>"
    rstr=rstr+"<th>Update</th><th>Delete</th></tr>"
    cnt=0
    did=-1
    for result in DBData:
        cnt=0
        ll=['A','B','C','D','E','F','G','H','I','J','K']
        for row in result:
            if cnt==0:
                did=row
                rstr=rstr+"<td>"+str(row)+"</td>" 
            
            else:
                rstr=rstr+"<td>"+"<input type=text id="+str(ll[cnt])+str(did)+" value=\""+str(row)+"\"></td>"     
            cnt+=1
            
        rstr+="<td><a ><i class=\"fa fa-edit\" aria-hidden=\"true\" onclick=update("+str(did)+")></i></a></td>"
        rstr+="<td><a ><i class=\"fa fa-trash\" aria-hidden=\"true\" onclick=del("+str(did)+")></i></a></td>"
        
        rstr=rstr+"</tr>"
    
    rstr=rstr+"</table>"
    rstr=rstr+'''
    <script type=\"text/javascript\">
    function update(did)
    {
       title=$("#B"+did).val();
       author=$("#C"+did).val();
       price=$("#D"+did).val();
       noc=$("#E"+did).val();
       $.ajax({
        url: \"/bookupdate\",
        type: \"POST\",
        data: {did:did,title:title,author:author,price:price,noc:noc},
        success: function(data){    
        alert(data);
        loadbooks();
        }
       });
    }
   
    function del(did)
    {
    $.ajax({
        url: \"/bookdelete\",
        type: \"POST\",
        data: {did:did},
        success: function(data){
            alert(data);
            loadbooks();
        }
        });
    }
    function loadbooks(){

       $.ajax({
        url: 'http://127.0.0.1:5000/bookshow',
        type: 'POST',
        success: function(data){
          $('#viewBook').html(data);
        }
      });
    }
    
    
    </script>

'''
    return rstr


@app.route('/bookupdate', methods=['GET', 'POST'])

def bookupdate():
    isbn=request.form.get('did')
    title=request.form.get('title')
    author=request.form.get('author')
    price=request.form.get('price')
    noc=request.form.get('noc')
    
    cursor = mysql.connection.cursor()
    cursor.execute(''' UPDATE book SET TITTLE=%s,AUTHOR=%s,PRICE=%s,NO_OF_COPIES=%s WHERE ISBN=%s''',(title,author,price,noc,isbn))
    mysql.connection.commit()
    cursor.close()
    return "Updated successfully"

@app.route('/bookdelete', methods =['GET', 'POST'])
def rdelete():
    
    isbn=request.form.get('did')
    cursor = mysql.connection.cursor()
    cursor.execute(''' DELETE FROM book WHERE ISBN=%s''',(isbn,))
    mysql.connection.commit()
    cursor.close()
    return "Deleted successfully"
@app.route('/view_books')
def view_books():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM book")
    books = cur.fetchall()
    cur.close()
    return render_template('book_manegement.html', books=books)

@app.route('/view_lended_books')
def view_lended_books():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM lending")
    lended_books = cur.fetchall()
    cur.close()
    return render_template('view_lended_books.html', lended_books=lended_books)

@app.route('/return_book', methods=['POST'])
def return_book():
    isbn = request.form.get('isbn')
    usn = request.form.get('usn')

    cur = mysql.connection.cursor()

   
    cur.execute("UPDATE lending SET DATE_DUE = CURDATE() WHERE ISBN = %s AND USN = %s AND DATE_DUE IS NULL", (isbn, usn))
    mysql.connection.commit()
    cur.execute("UPDATE book SET NO_OF_COPIES = NO_OF_COPIES + 1 WHERE ISBN = %s", (isbn,))
    mysql.connection.commit()
    cur.close()

    return 'Book returned successfully'


if __name__ == '__main__':
    app.run(debug=True)
